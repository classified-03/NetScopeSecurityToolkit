package com.netscope.security;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16,24,32), panel = Color.rgb(28,40,50), accent = Color.rgb(53,201,154);
    private EditText targets, customPorts;
    private CheckBox[] portChecks;
    private TextView output, status;
    private Button scanButton;
    private ExecutorService pool;
    private volatile boolean scanning = false;
    private static final int PICK_TXT = 10;
    private static final int[] PORTS = {21,22,23,80,443,554,8080,2323};
    private static final String[] PORT_NAMES = {"FTP","SSH","Telnet","HTTP","HTTPS","RTSP","HTTP alt.","Telnet alt."};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(0,6,0,6); return t;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,22,18,24); root.setBackgroundColor(bg); scroll.addView(root);
        TextView title = text("NETSCOPE",28,Color.WHITE); title.setTypeface(null,1); root.addView(title);
        TextView sub = text("SECURITY TOOLKIT  •  ANDROID",12,accent); root.addView(sub);
        root.addView(text("IP adrese / opsezi",16,Color.WHITE));
        targets = new EditText(this); targets.setTextColor(Color.WHITE); targets.setHintTextColor(0xff9aabb7); targets.setHint("npr. 192.168.1.1-192.168.1.40, 10.0.0.5 ili CIDR /24"); targets.setMinLines(2); targets.setGravity(Gravity.TOP); targets.setBackgroundColor(panel); targets.setPadding(12,10,12,10); root.addView(targets);
        Button importBtn = button("UVEZI TXT / CSV"); root.addView(importBtn); importBtn.setOnClickListener(v -> { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("text/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_TXT); });
        root.addView(text("Portovi za proveru",16,Color.WHITE));
        LinearLayout grid = new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL); grid.setBackgroundColor(panel); grid.setPadding(10,8,10,8); root.addView(grid);
        portChecks = new CheckBox[PORTS.length];
        for(int i=0;i<PORTS.length;i++){ CheckBox c=new CheckBox(this); c.setText(PORTS[i]+"  •  "+PORT_NAMES[i]); c.setTextColor(Color.WHITE); c.setButtonTintList(android.content.res.ColorStateList.valueOf(accent)); c.setChecked(true); portChecks[i]=c; grid.addView(c); }
        customPorts = new EditText(this); customPorts.setTextColor(Color.WHITE); customPorts.setHintTextColor(0xff9aabb7); customPorts.setHint("Dodatni portovi, npr. 8000, 8443"); customPorts.setInputType(InputType.TYPE_CLASS_TEXT); customPorts.setBackgroundColor(panel); customPorts.setPadding(12,8,12,8); root.addView(customPorts);
        TextView note=text("Koristi samo na uređajima i mrežama za koje imaš dozvolu. Ograničenje: najviše 256 IP adresa po skeniranju.",12,0xffffc66d); root.addView(note);
        scanButton=button("▶  START FULL SCAN"); root.addView(scanButton); scanButton.setOnClickListener(v -> startScan());
        status=text("Spreman za skeniranje",13,accent); root.addView(status);
        root.addView(text("REZULTATI",16,Color.WHITE));
        output=text("Ovde će se prikazati pronađeni uređaji i otvoreni portovi.",13,0xffdce5eb); output.setTypeface(android.graphics.Typeface.MONOSPACE); output.setBackgroundColor(panel); output.setPadding(12,12,12,12); root.addView(output);
        root.addView(text("Dodatna provera uređaja",16,Color.WHITE));
        Button sshBtn=button("SSH SYSTEM INSPECTION"); root.addView(sshBtn); sshBtn.setOnClickListener(v -> showSshDialog());
        TextView sshNote=text("SSH komande uname -a, uname -m i /proc/cpuinfo pokreću se samo nakon tvog ručnog izbora uređaja i unosa pristupnih podataka. Skeniranje ne pokušava lozinke.",12,0xff9aabb7); root.addView(sshNote);
        Button export=button("IZVEZI IZVEŠTAJ (TXT)"); root.addView(export); export.setOnClickListener(v -> saveReport());
        setContentView(scroll);
    }
    private Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff245c55)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,9,0,9); b.setLayoutParams(lp); return b; }

    private void startScan(){
        if(scanning) return;
        final List<String> hosts;
        try { hosts=parseTargets(targets.getText().toString()); } catch(Exception e){ toast(e.getMessage()); return; }
        if(hosts.isEmpty()){ toast("Unesi IP adresu, opseg ili CIDR."); return; }
        if(hosts.size()>256){ toast("Previše adresa. Maksimum je 256 po skeniranju."); return; }
        List<Integer> ports=new ArrayList<>(); for(int i=0;i<PORTS.length;i++) if(portChecks[i].isChecked()) ports.add(PORTS[i]);
        try { for(String p:customPorts.getText().toString().split(",")){ if(!p.trim().isEmpty()){int n=Integer.parseInt(p.trim()); if(n<1||n>65535) throw new Exception(); if(!ports.contains(n)) ports.add(n); }} } catch(Exception e){ toast("Proveri dodatne portove (1–65535)."); return; }
        if(ports.isEmpty()){ toast("Izaberi najmanje jedan port."); return; }
        scanning=true; scanButton.setEnabled(false); status.setText("Skeniranje u toku: "+hosts.size()+" IP adresa"); output.setText("");
        pool=Executors.newFixedThreadPool(24);
        new Thread(() -> {
            StringBuilder report=new StringBuilder(); int found=0;
            for(String host:hosts){
                if(!scanning) break;
                List<Future<String>> fs=new ArrayList<>();
                for(int port:ports){ final int p=port; fs.add(pool.submit(() -> probe(host,p))); }
                List<String> open=new ArrayList<>();
                for(Future<String> f:fs){ try{String r=f.get(3,TimeUnit.SECONDS); if(r!=null) open.add(r);}catch(Exception ignored){} }
                if(!open.isEmpty()){
                    found++; report.append("\nIP: ").append(host).append("\n");
                    for(String r:open) report.append("  ").append(r).append("\n");
                    report.append("  Napomena: OS/CPU nisu pouzdano dostupni samo TCP skeniranjem.\n");
                }
                final String snap=report.toString(); final int count=found; runOnUiThread(() -> { output.setText(snap); status.setText("Provereno "+(hosts.indexOf(host)+1)+" / "+hosts.size()+" • uređaja sa otvorenim portovima: "+count); });
            }
            if(pool!=null) pool.shutdownNow(); scanning=false;
            final int finalFound=found; runOnUiThread(() -> { scanButton.setEnabled(true); status.setText("Završeno • uređaja sa otvorenim portovima: "+finalFound); if(report.length()==0) output.setText("Nije pronađen nijedan otvoren izabrani port."); });
        }).start();
    }
    private String probe(String host,int port){
        try(Socket s=new Socket()){
            s.connect(new InetSocketAddress(host,port),1300); s.setSoTimeout(700);
            String service=serviceName(port), banner="";
            try {
                if(port==80||port==8080){ byte[] req=("HEAD / HTTP/1.0\r\nHost: "+host+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII); s.getOutputStream().write(req); s.getOutputStream().flush(); }
                byte[] buf=new byte[512]; int n=s.getInputStream().read(buf); if(n>0) banner=new String(buf,0,n,StandardCharsets.UTF_8).replace('\r',' ').replace('\n',' ').trim();
            } catch(Exception ignored){}
            if(!banner.isEmpty()) service += " | "+banner.substring(0,Math.min(100,banner.length()));
            if(port==23||port==2323) service += " | Telnet otvoren; zahtev za prijavu nije potvrđen automatski";
            return port+" OPEN • "+service;
        }catch(Exception e){return null;}
    }
    private String serviceName(int p){ switch(p){case 21:return "FTP";case 22:return "SSH";case 23:return "Telnet";case 80:return "HTTP";case 443:return "HTTPS";case 554:return "RTSP";case 8080:return "HTTP alternate";case 2323:return "Telnet alternate";default:return "TCP service";} }

    private List<String> parseTargets(String raw) throws Exception {
        List<String> out=new ArrayList<>();
        for(String token:raw.split("[,;\\s]+")){ if(token.trim().isEmpty()) continue; String t=token.trim();
            if(t.contains("/")){ String[] a=t.split("/"); long ip=ipToLong(a[0]); int bits=Integer.parseInt(a[1]); if(bits<24||bits>32) throw new Exception("CIDR dozvoljen od /24 do /32 (maks. 256 adresa)."); long count=1L<<(32-bits); if(count>256) throw new Exception("CIDR opseg je veći od 256 adresa."); long mask=bits==0?0:(0xffffffffL << (32-bits))&0xffffffffL; long start=ip&mask; for(long x=0;x<count;x++) out.add(longToIp(start+x));
            } else if(t.contains("-")){ String[] a=t.split("-"); long st=ipToLong(a[0]),en=ipToLong(a[1]); if(en<st||en-st+1>256) throw new Exception("Neispravan opseg ili više od 256 adresa."); for(long x=st;x<=en;x++) out.add(longToIp(x));
            } else { ipToLong(t); out.add(t); }
            if(out.size()>256) throw new Exception("Maksimum je 256 IP adresa po skeniranju.");
        }
        return new ArrayList<>(new java.util.LinkedHashSet<>(out));
    }
    private long ipToLong(String ip) throws Exception { String[] p=ip.split("\\."); if(p.length!=4) throw new Exception("Neispravna IPv4 adresa: "+ip); long v=0; for(String x:p){int n=Integer.parseInt(x); if(n<0||n>255) throw new Exception("Neispravna IPv4 adresa: "+ip); v=(v<<8)|n;} return v; }
    private String longToIp(long v){return ((v>>24)&255)+"."+((v>>16)&255)+"."+((v>>8)&255)+"."+(v&255);}

    private void showSshDialog(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(20,4,20,4);
        EditText host=field("IP adresa uređaja"); EditText user=field("SSH korisničko ime"); EditText pass=field("SSH lozinka"); pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(host);box.addView(user);box.addView(pass);
        new AlertDialog.Builder(this).setTitle("Ovlašćena SSH inspekcija").setMessage("Ručno izaberi uređaj i unesi svoje pristupne podatke. Lozinka se ne čuva.").setView(box).setNegativeButton("Otkaži",null).setPositiveButton("Pokreni uname / CPU",(d,w)->runSsh(host.getText().toString().trim(),user.getText().toString().trim(),pass.getText().toString())).show();
    }
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);return e;}
    private void runSsh(String host,String user,String pass){
        if(host.isEmpty()||user.isEmpty()||pass.isEmpty()){toast("Popuni sva polja.");return;}
        status.setText("Povezivanje preko SSH...");
        new Thread(()->{
            String result;
            Session session=null;
            try{
                JSch jsch=new JSch(); session=jsch.getSession(user,host,22); session.setPassword(pass);
                // First-use host key is shown to the user for confirmation before credentials are sent.
                session.setConfig("StrictHostKeyChecking","ask");
                session.setUserInfo(new com.jcraft.jsch.UserInfo(){
                    public String getPassphrase(){return null;} public String getPassword(){return pass;}
                    public boolean promptPassword(String m){return true;} public boolean promptPassphrase(String m){return false;}
                    public boolean promptYesNo(String m){ final AtomicBoolean ok=new AtomicBoolean(false); final CountDownLatch latch=new CountDownLatch(1); runOnUiThread(()->new AlertDialog.Builder(MainActivity.this).setTitle("SSH host key potvrda").setMessage(m+"\n\nProveri da li fingerprint pripada tvom uređaju. Nastavi samo ako ga prepoznaješ.").setPositiveButton("Verujem ovom uređaju",(a,b)->{ok.set(true);latch.countDown();}).setNegativeButton("Odbij",(a,b)->{ok.set(false);latch.countDown();}).setOnCancelListener(d->latch.countDown()).show()); try{latch.await(60,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();} return ok.get(); }
                    public void showMessage(String m){}
                });
                session.connect(7000);
                String cmd="uname -a; echo '\\n--- ARCH ---'; uname -m; echo '\\n--- CPUINFO ---'; head -n 24 /proc/cpuinfo; echo '\\n--- OS RELEASE ---'; cat /etc/os-release 2>/dev/null | head -n 12";
                ChannelExec ch=(ChannelExec)session.openChannel("exec"); ch.setCommand(cmd); ch.setInputStream(null); ByteArrayOutputStream out=new ByteArrayOutputStream(); ch.setOutputStream(out); ch.connect(5000);
                long end=System.currentTimeMillis()+10000; while(!ch.isClosed()&&System.currentTimeMillis()<end) Thread.sleep(150); ch.disconnect(); result=out.toString("UTF-8"); if(result.trim().isEmpty()) result="Nema izlaza komandi ili uređaj ne dozvoljava njihovo izvršavanje.";
            }catch(Exception e){result="SSH inspekcija nije uspela: "+e.getMessage();}finally{if(session!=null)session.disconnect();}
            final String r=result; runOnUiThread(()->{output.append("\n\n===== SSH SYSTEM INSPECTION =====\n"+r+"\n");status.setText("SSH inspekcija završena");});
        }).start();
    }
    private void saveReport(){ Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"netscope-report.txt");startActivityForResult(i,11); }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{if(req==PICK_TXT){InputStream in=getContentResolver().openInputStream(data.getData());BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line).append('\n');targets.append((targets.length()>0?",":"")+b.toString().replace('\n',','));in.close();}else if(req==11){java.io.OutputStream o=getContentResolver().openOutputStream(data.getData());o.write(output.getText().toString().getBytes(StandardCharsets.UTF_8));o.close();toast("Izveštaj sačuvan.");}}catch(Exception e){toast("Greška: "+e.getMessage());}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){scanning=false;if(pool!=null)pool.shutdownNow();super.onDestroy();}
}
