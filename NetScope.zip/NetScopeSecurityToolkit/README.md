# NetScope Security Toolkit (Android)

Android Java project for authorized network inventory and device diagnostics.

## Included
- IPv4 single address, explicit range, and CIDR target input (maximum 256 hosts per run; CIDR /24 to /32).
- TXT/CSV import via Android document picker.
- Selectable TCP ports: FTP 21, SSH 22, Telnet 23, HTTP 80, HTTPS 443, RTSP 554, HTTP-alt 8080, Telnet-alt 2323, plus custom ports.
- Bounded concurrent TCP connect checks and limited service/banner hints.
- Manual, user-initiated SSH inspection (`uname -a`, `uname -m`, `/proc/cpuinfo`, `/etc/os-release`). Credentials are not persisted. The SSH host-key fingerprint must be reviewed and accepted on first connection.
- TXT report export.
- GitHub Actions workflow to build a debug APK in the cloud, so a PC is not required after the project is uploaded to a GitHub repository.

## Important limitations
- A TCP scan cannot reliably determine a remote device's exact manufacturer, model, CPU or operating system. These fields require trustworthy service disclosures or authenticated system inspection. Unknown values must remain unknown rather than guessed.
- Port-open status does not prove that a device is unlocked or that authentication is absent. This version does not automatically try default passwords, wordlists, RockYou or brute-force. SSH system inspection is a separate manual action using credentials you provide for a device you administer.
- Telnet/FTP are plaintext protocols. Prefer SSH or a VPN for remote administration. Do not expose Telnet to the public internet.
- Only scan IP addresses and networks for which you have explicit authorization. Each run is limited to 256 IPv4 addresses and uses connection timeouts.
- The app does not automatically run `uname` against every scanned IP; those commands require a successful, manually initiated SSH login.

## Build without a computer (using Android browser)
1. In your Android browser, sign in to GitHub and create a **private** repository named `NetScopeSecurityToolkit`.
2. Upload the contents of this project ZIP to the repository (upload the files inside the `NetScopeSecurityToolkit` folder, not the enclosing folder itself).
3. Open the repository's **Actions** tab and enable Actions if GitHub asks.
4. Select **Build Android APK** and press **Run workflow**. Wait for the run to finish successfully.
5. Open the completed run, find **Artifacts**, and download `NetScope-debug-APK`. Extract it and install `app-debug.apk` on Android. Android may ask you to allow installation from that browser/file manager.

The GitHub Actions workflow builds an installable debug APK; it is not a Play Store release and is not a production signing setup. Keep the repository private because source code and build artifacts belong to you.

## Local build (optional)
Open the project in Android Studio, use JDK 17, Android SDK platform 35 and Gradle 8.9, then run `:app:assembleDebug`.
