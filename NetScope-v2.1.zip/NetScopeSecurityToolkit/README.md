# NetScope Security Toolkit 2.1 (Android)

Android Java app for authorized local-network inventory and defensive exposure checks.

## New in 2.1
- Simplified dashboard: IP input and scan action are visible immediately; port selection and custom ports are tucked into Advanced Settings.
- Scan results show a short device summary first; the full technical report opens separately and remains available for TXT export.
- Factory-login status is reported conservatively. AVM/FRITZ devices are not tested with generic credentials because there is no universal admin/admin pair; use the FRITZ!Box password or the device-specific password according to its setup.

## New in 2.0
- Automatic reverse-DNS hostname lookup and best-effort local ARP/MAC lookup.
- UPnP/SSDP discovery using a standard multicast M-SEARCH request; reads device-description XML when advertised (friendly name, manufacturer, model, model number, serial number and device type).
- HTTP root-page inspection: status, server header, title, redirects and authentication challenge indicators. It does not try passwords or crawl private paths.
- HTTPS/TLS inspection using Android's normal certificate trust and hostname validation; it does not bypass certificate errors.
- RTSP OPTIONS capability check only; it does not open or record a video stream.
- Heuristic exposure rating with explanations and remediation guidance for Telnet, FTP, plain HTTP and RTSP.
- Existing manual SSH inspection can read kernel/OS/CPU details after the user selects a device, verifies its SSH host key and supplies their own credentials. Credentials are not saved.

## Existing features
- IPv4 single address, explicit range and CIDR target input (maximum 256 hosts per run; CIDR /24 to /32).
- TXT/CSV import.
- Selectable TCP ports: FTP 21, SSH 22, Telnet 23, HTTP 80, HTTPS 443, RTSP 554, HTTP-alt 8080, Telnet-alt 2323, plus custom ports.
- Bounded concurrent TCP checks and TXT report export.
- Cloud APK build using GitHub Actions.

## Important limitations
- Manufacturer/model are shown only when the device discloses them through UPnP/SSDP or another reliable service response. ARP MAC lookup is best-effort and Android may restrict access to the ARP table.
- A TCP scan cannot reliably determine exact OS, firmware, CPU or architecture. Those require a trustworthy disclosure or an authenticated SSH session.
- An HTTP 200 response or RTSP OPTIONS response does not prove that administrative functions or video streams are unauthenticated.
- The exposure rating is a transparent heuristic, not a CVE scanner, penetration test, malware detector or proof of botnet infection. Open ports alone do not prove compromise.
- This app does not perform brute force, password spraying, wordlist attacks, or exploit attempts. It does not silently change device credentials. Model-specific factory-login checks are only appropriate when a reliable documented default is available; unsupported devices are marked as not tested.
- Telnet/FTP are plaintext protocols. Prefer SSH/SFTP/FTPS or a VPN, and do not expose device administration to the public internet.
- Only scan IP addresses and networks for which you have explicit authorization. Each run is limited to 256 IPv4 addresses.

## Build
Use JDK 17, Android SDK platform 35 and Gradle 8.9, or the included GitHub Actions workflow.
