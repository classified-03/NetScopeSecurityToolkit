package com.netscope.security;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.URL;
import java.net.HttpURLConnection;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16,24,32), panel = Color.rgb(28,40,50), accent = Color.rgb(53,201,154);
    private EditText targets, customPorts;
    private CheckBox[] portChecks;
    private TextView output, status;
    private Button scanButton;
    private ExecutorService pool;
    private volatile boolean scanning = false;
    private static final int PICK_TXT = 10;
    private static final int[] PORTS = {21,22,23,80,443,554,8080,2323};
    private static final String[] PORT_NAMES = {"FTP","SSH","Telnet","HTTP","HTTPS","RTSP","HTTP alt.","Telnet alt."};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(0,6,0,6); return t;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,22,18,24); root.setBackgroundColor(bg); scroll.addView(root);
        TextView title = text("NETSCOPE",28,Color.WHITE); title.setTypeface(null,1); root.addView(title);
        TextView sub = text("SECURITY TOOLKIT  •  ANDROID",12,accent); root.addView(sub);
        root.addView(text("IP adrese / opsezi",16,Color.WHITE));
        targets = new EditText(this); targets.setTextColor(Color.WHITE); targets.setHintTextColor(0xff9aabb7); targets.setHint("npr. 192.168.1.1-192.168.1.40, 10.0.0.5 ili CIDR /24"); targets.setMinLines(2); targets.setGravity(Gravity.TOP); targets.setBackgroundColor(panel); targets.setPadding(12,10,12,10); root.addView(targets);
        Button importBtn = button("UVEZI TXT / CSV"); root.addView(importBtn); importBtn.setOnClickListener(v -> { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("text/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_TXT); });
        root.addView(text("Portovi za proveru",16,Color.WHITE));
        LinearLayout grid = new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL); grid.setBackgroundColor(panel); grid.setPadding(10,8,10,8); root.addView(grid);
        portChecks = new CheckBox[PORTS.length];
        for(int i=0;i<PORTS.length;i++){ CheckBox c=new CheckBox(this); c.setText(PORTS[i]+"  •  "+PORT_NAMES[i]); c.setTextColor(Color.WHITE); c.setButtonTintList(android.content.res.ColorStateList.valueOf(accent)); c.setChecked(true); portChecks[i]=c; grid.addView(c); }
        customPorts = new EditText(this); customPorts.setTextColor(Color.WHITE); customPorts.setHintTextColor(0xff9aabb7); customPorts.setHint("Dodatni portovi, npr. 8000, 8443"); customPorts.setInputType(InputType.TYPE_CLASS_TEXT); customPorts.setBackgroundColor(panel); customPorts.setPadding(12,8,12,8); root.addView(customPorts);
        TextView note=text("Koristi samo na uređajima i mrežama za koje imaš dozvolu. Ograničenje: najviše 256 IP adresa po skeniranju.",12,0xffffc66d); root.addView(note);
        scanButton=button("▶  START FULL SCAN"); root.addView(scanButton); scanButton.setOnClickListener(v -> startScan());
        status=text("Spreman za skeniranje",13,accent); root.addView(status);
        root.addView(text("REZULTATI",16,Color.WHITE));
        output=text("Ovde će se prikazati pronađeni uređaji i otvoreni portovi.",13,0xffdce5eb); output.setTypeface(android.graphics.Typeface.MONOSPACE); output.setBackgroundColor(panel); output.setPadding(12,12,12,12); root.addView(output);
        root.addView(text("Dodatna provera uređaja",16,Color.WHITE));
        Button sshBtn=button("SSH SYSTEM INSPECTION"); root.addView(sshBtn); sshBtn.setOnClickListener(v -> showSshDialog());
        TextView sshNote=text("Automatska analiza koristi DNS/ARP, UPnP/SSDP, HTTP/HTTPS zaglavlja i RTSP OPTIONS. CPU/OS se čitaju samo preko SSH naloga koji ti ručno uneseš. Nema brute-force pokušaja.",12,0xff9aabb7); root.addView(sshNote);
        Button export=button("IZVEZI IZVEŠTAJ (TXT)"); root.addView(export); export.setOnClickListener(v -> saveReport());
        setContentView(scroll);
    }
    private Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff245c55)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,9,0,9); b.setLayoutParams(lp); return b; }

    private void startScan(){
        if(scanning) return;
        final List<String> hosts;
        try { hosts=parseTargets(targets.getText().toString()); } catch(Exception e){ toast(e.getMessage()); return; }
        if(hosts.isEmpty()){ toast("Unesi IP adresu, opseg ili CIDR."); return; }
        if(hosts.size()>256){ toast("Previše adresa. Maksimum je 256 po skeniranju."); return; }
        List<Integer> ports=new ArrayList<>(); for(int i=0;i<PORTS.length;i++) if(portChecks[i].isChecked()) ports.add(PORTS[i]);
        try { for(String p:customPorts.getText().toString().split(",")){ if(!p.trim().isEmpty()){int n=Integer.parseInt(p.trim()); if(n<1||n>65535) throw new Exception(); if(!ports.contains(n)) ports.add(n); }} } catch(Exception e){ toast("Proveri dodatne portove (1–65535)."); return; }
        if(ports.isEmpty()){ toast("Izaberi najmanje jedan port."); return; }
        scanning=true; scanButton.setEnabled(false); status.setText("Otkrivanje UPnP uređaja i priprema analize..."); output.setText("");
        pool=Executors.newFixedThreadPool(24);
        new Thread(() -> {
            StringBuilder report=new StringBuilder(); int found=0, high=0, medium=0;
            Map<String,SsdpDevice> ssdp=discoverSsdp();
            Map<String,String> arp=readArpTable();
            for(int index=0; index<hosts.size(); index++){
                if(!scanning) break;
                String host=hosts.get(index);
                List<Future<String>> fs=new ArrayList<>();
                for(int port:ports){ final int p=port; fs.add(pool.submit(() -> probe(host,p))); }
                List<String> open=new ArrayList<>();
                for(Future<String> f:fs){ try{String r=f.get(3,TimeUnit.SECONDS); if(r!=null) open.add(r);}catch(Exception ignored){} }
                if(!open.isEmpty()){
                    found++;
                    HostAudit audit=auditHost(host, open, ssdp.get(host), arp.get(host));
                    if(audit.riskLevel.equals("VISOK")) high++; else if(audit.riskLevel.equals("SREDNJI")) medium++;
                    report.append(audit.report).append("\n\n");
                }
                final String snap=report.toString(); final int count=found, hi=high, med=medium, done=index+1;
                runOnUiThread(() -> { output.setText(snap); status.setText("Provereno "+done+" / "+hosts.size()+" • uređaji: "+count+" • visok rizik: "+hi+" • srednji: "+med); });
            }
            if(pool!=null) pool.shutdownNow(); scanning=false;
            final int finalFound=found, finalHigh=high, finalMedium=medium;
            runOnUiThread(() -> { scanButton.setEnabled(true); status.setText("Završeno • uređaja: "+finalFound+" • visok rizik: "+finalHigh+" • srednji rizik: "+finalMedium); if(report.length()==0) output.setText("Nije pronađen nijedan otvoren izabrani port. Proveri da li je telefon na istoj lokalnoj mreži."); });
        }).start();
    }

    private String probe(String host,int port){
        try(Socket s=new Socket()){
            s.connect(new InetSocketAddress(host,port),1300); s.setSoTimeout(700);
            String service=serviceName(port), banner="";
            try {
                if(port==80||port==8080){ byte[] req=("HEAD / HTTP/1.0\r\nHost: "+host+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII); s.getOutputStream().write(req); s.getOutputStream().flush(); }
                byte[] buf=new byte[512]; int n=s.getInputStream().read(buf); if(n>0) banner=new String(buf,0,n,StandardCharsets.UTF_8).replace('\r',' ').replace('\n',' ').trim();
            } catch(Exception ignored){}
            if(!banner.isEmpty()) service += " | "+banner.substring(0,Math.min(100,banner.length()));
            if(port==23||port==2323) service += " | Telnet otvoren; zahtev za prijavu nije potvrđen automatski";
            return port+" OPEN • "+service;
        }catch(Exception e){return null;}
    }
    private String serviceName(int p){ switch(p){case 21:return "FTP";case 22:return "SSH";case 23:return "Telnet";case 80:return "HTTP";case 443:return "HTTPS";case 554:return "RTSP";case 8080:return "HTTP alternate";case 2323:return "Telnet alternate";default:return "TCP service";} }

    private static class SsdpDevice {
        String location="", server="", st="", usn="", manufacturer="", modelName="", modelNumber="", friendlyName="", serialNumber="", deviceType="";
    }
    private static class HostAudit {
        String report="", riskLevel="NIZAK";
    }

    // SSDP/UPnP discovery is passive apart from a standard multicast M-SEARCH request.
    // It does not authenticate, change settings, or access media streams.
    private Map<String,SsdpDevice> discoverSsdp(){
        Map<String,SsdpDevice> found=new HashMap<>();
        WifiManager.MulticastLock lock=null;
        DatagramSocket socket=null;
        try{
            WifiManager wm=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
            if(wm!=null){ lock=wm.createMulticastLock("NetScope-SSDP"); lock.setReferenceCounted(false); lock.acquire(); }
            socket=new DatagramSocket(); socket.setSoTimeout(300); socket.setBroadcast(true);
            String req="M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: ssdp:all\r\nUSER-AGENT: NetScope/2.0 UPnP/1.1\r\n\r\n";
            byte[] data=req.getBytes(StandardCharsets.US_ASCII);
            socket.send(new DatagramPacket(data,data.length,InetAddress.getByName("239.255.255.250"),1900));
            long until=System.currentTimeMillis()+1800;
            while(System.currentTimeMillis()<until){
                try{
                    byte[] buf=new byte[8192]; DatagramPacket packet=new DatagramPacket(buf,buf.length); socket.receive(packet);
                    String raw=new String(packet.getData(),0,packet.getLength(),StandardCharsets.UTF_8);
                    SsdpDevice d=new SsdpDevice();
                    for(String line:raw.split("\\r?\\n")){ int k=line.indexOf(':'); if(k<1) continue; String key=line.substring(0,k).trim().toLowerCase(Locale.ROOT), val=line.substring(k+1).trim();
                        if(key.equals("location")) d.location=val; else if(key.equals("server")) d.server=val; else if(key.equals("st")) d.st=val; else if(key.equals("usn")) d.usn=val;
                    }
                    String ip=packet.getAddress().getHostAddress();
                    if(!d.location.isEmpty()){
                        fetchSsdpDescription(d); found.put(ip,d);
                    } else if(!found.containsKey(ip)) found.put(ip,d);
                }catch(java.net.SocketTimeoutException timeout){}
            }
        }catch(Exception ignored){}
        finally{ if(socket!=null) socket.close(); if(lock!=null&&lock.isHeld()) lock.release(); }
        return found;
    }

    private void fetchSsdpDescription(SsdpDevice d){
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(d.location).openConnection(); c.setConnectTimeout(1800); c.setReadTimeout(1800); c.setRequestMethod("GET"); c.setRequestProperty("User-Agent","NetScope/2.0");
            if(c.getResponseCode()>=200&&c.getResponseCode()<300){
                InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] b=new byte[2048]; int n,total=0;
                while((n=in.read(b))>0&&total<32768){out.write(b,0,n);total+=n;} in.close();
                DocumentBuilderFactory f=DocumentBuilderFactory.newInstance(); f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true); f.setFeature("http://xml.org/sax/features/external-general-entities",false); f.setFeature("http://xml.org/sax/features/external-parameter-entities",false); f.setExpandEntityReferences(false);
                Document doc=f.newDocumentBuilder().parse(new InputSource(new java.io.ByteArrayInputStream(out.toByteArray())));
                d.manufacturer=xmlTag(doc,"manufacturer"); d.modelName=xmlTag(doc,"modelName"); d.modelNumber=xmlTag(doc,"modelNumber"); d.friendlyName=xmlTag(doc,"friendlyName"); d.serialNumber=xmlTag(doc,"serialNumber"); d.deviceType=xmlTag(doc,"deviceType");
            }
        }catch(Exception ignored){} finally{if(c!=null)c.disconnect();}
    }
    private String xmlTag(Document d,String tag){ try{org.w3c.dom.NodeList n=d.getElementsByTagName(tag); if(n.getLength()>0)return n.item(0).getTextContent().trim();}catch(Exception ignored){} return ""; }

    private Map<String,String> readArpTable(){
        Map<String,String> map=new HashMap<>();
        try(BufferedReader r=new BufferedReader(new FileReader("/proc/net/arp"))){ String line; r.readLine(); while((line=r.readLine())!=null){String[] a=line.trim().split("\\s+"); if(a.length>=4&&!a[3].equals("00:00:00:00:00:00")) map.put(a[0],a[3].toUpperCase(Locale.ROOT));}}
        catch(Exception ignored){}
        return map;
    }

    private HostAudit auditHost(String host,List<String> open,SsdpDevice upnp,String mac){
        HostAudit a=new HostAudit(); StringBuilder b=new StringBuilder();
        b.append("IP: ").append(host).append("\\n");
        String hostname=host;
        try{String h=InetAddress.getByName(host).getCanonicalHostName(); if(h!=null&&!h.equals(host)) hostname=h;}catch(Exception ignored){}
        b.append("Hostname: ").append(hostname).append("\\n");
        if(mac!=null) b.append("MAC (ARP): ").append(mac).append("\\n"); else b.append("MAC: nije dostupan Android ARP tabeli\\n");
        String kind="Nepoznat uređaj";
        if(upnp!=null){
            if(!upnp.friendlyName.isEmpty()) kind=upnp.friendlyName;
            else if(!upnp.deviceType.isEmpty()) kind=upnp.deviceType.substring(upnp.deviceType.lastIndexOf(':')+1);
            b.append("UPnP/SSDP: pronađen\\n");
            if(!upnp.manufacturer.isEmpty()) b.append("Proizvođač: ").append(upnp.manufacturer).append("\\n");
            if(!upnp.modelName.isEmpty()) b.append("Model: ").append(upnp.modelName).append("\\n");
            if(!upnp.modelNumber.isEmpty()) b.append("Broj modela: ").append(upnp.modelNumber).append("\\n");
            if(!upnp.serialNumber.isEmpty()) b.append("Serijski broj: ").append(upnp.serialNumber).append("\\n");
            if(!upnp.deviceType.isEmpty()) b.append("UPnP tip: ").append(upnp.deviceType).append("\\n");
            if(!upnp.server.isEmpty()) b.append("UPnP server: ").append(upnp.server).append("\\n");
        } else b.append("UPnP/SSDP: nije oglasio podatke (ne znači da uređaj nema model)\\n");
        boolean hasRtsp=hasPort(open,554), hasHttp=hasPort(open,80)||hasPort(open,8080), hasSsh=hasPort(open,22), hasTelnet=hasPort(open,23)||hasPort(open,2323), hasFtp=hasPort(open,21);
        if(upnp==null||kind.equals("Nepoznat uređaj")){
            if(hasRtsp) kind="Moguća IP kamera / NVR / streaming uređaj (indikacija po RTSP portu)";
            else if(hasSsh&&hasHttp) kind="Mogući Linux/embedded mrežni uređaj (indikacija, nije potvrđeno)";
            else if(hasHttp) kind="Mrežni uređaj sa web servisom (tačan tip nepoznat)";
        }
        b.append("Tip uređaja: ").append(kind).append("\\n");
        b.append("Otvoreni portovi:\\n"); for(String x:open)b.append("  ").append(x).append("\\n");
        int score=0; List<String> risks=new ArrayList<>();
        if(hasTelnet){score+=45;risks.add("VISOK • Telnet dostupan (23/2323): protokol nema šifrovanje i može izložiti lozinke. Isključi ga ili ograniči pristup na pouzdanu mrežu/VPN.");}
        if(hasFtp){score+=20;risks.add("SREDNJI • FTP dostupan (21): klasični FTP može slati podatke i lozinke bez šifrovanja. Prednost daj SFTP/FTPS ili isključi servis.");}
        if(hasHttp){score+=10;risks.add("NIZAK/SREDNJI • HTTP web servis je dostupan bez TLS zaštite. Proveri da li je administracija potrebna i koristi HTTPS.");}
        if(hasRtsp){score+=10;risks.add("NIZAK/SREDNJI • RTSP servis je dostupan. Ova provera ne otvara video; proveri da li je pristup zaštićen lozinkom i ograničen na lokalnu mrežu.");}
        if(score>=45)a.riskLevel="VISOK"; else if(score>=20)a.riskLevel="SREDNJI"; else a.riskLevel="NIZAK";
        b.append("Procena izloženosti: ").append(a.riskLevel).append(" (heuristička, nije dokaz kompromitovanja)\\n");
        if(risks.isEmpty()) b.append("Nalaz: nema indikatora iz ove kratke provere; to nije garancija da je uređaj bezbedan.\\n");
        else {b.append("Nalazi i preporuke:\\n");for(String r:risks)b.append("  - ").append(r).append("\\n");}
        if(hasHttp){int port=hasPort(open,80)?80:8080; b.append(inspectHttp(host,port));}
        if(hasPort(open,443)) b.append(inspectHttps(host));
        if(hasRtsp) b.append(inspectRtsp(host));
        b.append("OS/CPU/firmware: nisu pouzdano utvrđeni mrežnim skeniranjem. Za detalje koristi SSH SYSTEM INSPECTION samo ako imaš svoj nalog.\\n");
        b.append("Napomena: otvoren port sam po sebi ne znači ranjivost ili botnet infekciju.");
        a.report=b.toString().replace("\\n","\n"); return a;
    }
    private boolean hasPort(List<String> open,int port){for(String s:open)if(s.startsWith(port+" OPEN"))return true;return false;}

    private String inspectHttp(String host,int port){
        HttpURLConnection c=null; StringBuilder b=new StringBuilder("HTTP analiza (samo početna stranica):\\n");
        try{
            c=(HttpURLConnection)new URL("http://"+host+":"+port+"/").openConnection(); c.setConnectTimeout(1800); c.setReadTimeout(1800); c.setInstanceFollowRedirects(false); c.setRequestMethod("GET"); c.setRequestProperty("User-Agent","NetScope/2.0 security-audit");
            int code=c.getResponseCode(); b.append("  Status: ").append(code).append(" ").append(c.getResponseMessage()).append("\\n");
            String server=c.getHeaderField("Server"), auth=c.getHeaderField("WWW-Authenticate"), loc=c.getHeaderField("Location");
            if(server!=null)b.append("  Server: ").append(server).append("\\n");
            if(auth!=null)b.append("  WWW-Authenticate: ").append(auth).append(" (zaštićeni resurs traži autentikaciju)\\n");
            else if(code==401||code==403)b.append("  Pristup ograničen; server nije dao WWW-Authenticate zaglavlje.\\n");
            if(loc!=null)b.append("  Preusmerenje: ").append(loc).append("\\n");
            InputStream in=(code>=400?c.getErrorStream():c.getInputStream());
            if(in!=null){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[1024];int n,total=0;while((n=in.read(buf))>0&&total<8192){out.write(buf,0,n);total+=n;}in.close();String html=out.toString("UTF-8");Matcher m=Pattern.compile("(?is)<title[^>]*>(.*?)</title>").matcher(html);if(m.find())b.append("  Naslov stranice: ").append(m.group(1).replaceAll("\\s+"," ").trim()).append("\\n");}
            if(code>=200&&code<400&&auth==null)b.append("  Napomena: početna stranica odgovara bez HTTP auth izazova; to NE dokazuje da su administrativne funkcije nezaštićene.\\n");
        }catch(Exception e){b.append("  HTTP detalji nisu dostupni: ").append(e.getClass().getSimpleName()).append("\\n");}finally{if(c!=null)c.disconnect();}
        return b.toString().replace("\\n","\n");
    }

    private String inspectHttps(String host){
        HttpsURLConnection c=null; StringBuilder b=new StringBuilder("HTTPS/TLS analiza:\\n");
        try{
            c=(HttpsURLConnection)new URL("https://"+host+"/").openConnection(); c.setConnectTimeout(1800); c.setReadTimeout(1800); c.setInstanceFollowRedirects(false); c.setRequestMethod("HEAD");
            int code=c.getResponseCode(); b.append("  HTTPS status: ").append(code).append("\\n");
            Certificate[] chain=c.getServerCertificates(); if(chain.length>0&&chain[0] instanceof X509Certificate){X509Certificate cert=(X509Certificate)chain[0];b.append("  Sertifikat za: ").append(cert.getSubjectX500Principal().getName()).append("\\n  Izdavalac: ").append(cert.getIssuerX500Principal().getName()).append("\\n  Važi do: ").append(cert.getNotAfter()).append("\\n");}
        }catch(javax.net.ssl.SSLHandshakeException e){b.append("  TLS sertifikat nije prihvaćen od Android trust store-a (moguć self-signed/istekao/pogrešan hostname); proveri ga na uređaju.\\n");}
        catch(Exception e){b.append("  TLS detalji nisu dostupni: ").append(e.getClass().getSimpleName()).append("\\n");}finally{if(c!=null)c.disconnect();}
        return b.toString().replace("\\n","\n");
    }

    private String inspectRtsp(String host){
        StringBuilder b=new StringBuilder("RTSP provera (OPTIONS, bez otvaranja video toka):\\n");
        try(Socket s=new Socket()){
            s.connect(new InetSocketAddress(host,554),1500);s.setSoTimeout(1200);
            s.getOutputStream().write(("OPTIONS * RTSP/1.0\r\nCSeq: 1\r\nUser-Agent: NetScope/2.0\r\n\r\n").getBytes(StandardCharsets.US_ASCII));s.getOutputStream().flush();
            BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));String line;int count=0;boolean challenge=false;
            while((line=r.readLine())!=null&&count++<12){if(line.toLowerCase(Locale.ROOT).startsWith("www-authenticate:"))challenge=true;b.append("  ").append(line).append("\\n");if(line.isEmpty())break;}
            if(!challenge)b.append("  OPTIONS odgovor nije dokaz da je video tok otvoren bez lozinke.\\n");
        }catch(Exception e){b.append("  RTSP OPTIONS nije odgovorio: ").append(e.getClass().getSimpleName()).append("\\n");}
        return b.toString().replace("\\n","\n");
    }

    private List<String> parseTargets(String raw) throws Exception {
        List<String> out=new ArrayList<>();
        for(String token:raw.split("[,;\\s]+")){ if(token.trim().isEmpty()) continue; String t=token.trim();
            if(t.contains("/")){ String[] a=t.split("/"); long ip=ipToLong(a[0]); int bits=Integer.parseInt(a[1]); if(bits<24||bits>32) throw new Exception("CIDR dozvoljen od /24 do /32 (maks. 256 adresa)."); long count=1L<<(32-bits); if(count>256) throw new Exception("CIDR opseg je veći od 256 adresa."); long mask=bits==0?0:(0xffffffffL << (32-bits))&0xffffffffL; long start=ip&mask; for(long x=0;x<count;x++) out.add(longToIp(start+x));
            } else if(t.contains("-")){ String[] a=t.split("-"); long st=ipToLong(a[0]),en=ipToLong(a[1]); if(en<st||en-st+1>256) throw new Exception("Neispravan opseg ili više od 256 adresa."); for(long x=st;x<=en;x++) out.add(longToIp(x));
            } else { ipToLong(t); out.add(t); }
            if(out.size()>256) throw new Exception("Maksimum je 256 IP adresa po skeniranju.");
        }
        return new ArrayList<>(new java.util.LinkedHashSet<>(out));
    }
    private long ipToLong(String ip) throws Exception { String[] p=ip.split("\\."); if(p.length!=4) throw new Exception("Neispravna IPv4 adresa: "+ip); long v=0; for(String x:p){int n=Integer.parseInt(x); if(n<0||n>255) throw new Exception("Neispravna IPv4 adresa: "+ip); v=(v<<8)|n;} return v; }
    private String longToIp(long v){return ((v>>24)&255)+"."+((v>>16)&255)+"."+((v>>8)&255)+"."+(v&255);}

    private void showSshDialog(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(20,4,20,4);
        EditText host=field("IP adresa uređaja"); EditText user=field("SSH korisničko ime"); EditText pass=field("SSH lozinka"); pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(host);box.addView(user);box.addView(pass);
        new AlertDialog.Builder(this).setTitle("Ovlašćena SSH inspekcija").setMessage("Ručno izaberi uređaj i unesi svoje pristupne podatke. Lozinka se ne čuva.").setView(box).setNegativeButton("Otkaži",null).setPositiveButton("Pokreni uname / CPU",(d,w)->runSsh(host.getText().toString().trim(),user.getText().toString().trim(),pass.getText().toString())).show();
    }
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);return e;}
    private void runSsh(String host,String user,String pass){
        if(host.isEmpty()||user.isEmpty()||pass.isEmpty()){toast("Popuni sva polja.");return;}
        status.setText("Povezivanje preko SSH...");
        new Thread(()->{
            String result;
            Session session=null;
            try{
                JSch jsch=new JSch(); session=jsch.getSession(user,host,22); session.setPassword(pass);
                // First-use host key is shown to the user for confirmation before credentials are sent.
                session.setConfig("StrictHostKeyChecking","ask");
                session.setUserInfo(new com.jcraft.jsch.UserInfo(){
                    public String getPassphrase(){return null;} public String getPassword(){return pass;}
                    public boolean promptPassword(String m){return true;} public boolean promptPassphrase(String m){return false;}
                    public boolean promptYesNo(String m){ final AtomicBoolean ok=new AtomicBoolean(false); final CountDownLatch latch=new CountDownLatch(1); runOnUiThread(()->new AlertDialog.Builder(MainActivity.this).setTitle("SSH host key potvrda").setMessage(m+"\n\nProveri da li fingerprint pripada tvom uređaju. Nastavi samo ako ga prepoznaješ.").setPositiveButton("Verujem ovom uređaju",(a,b)->{ok.set(true);latch.countDown();}).setNegativeButton("Odbij",(a,b)->{ok.set(false);latch.countDown();}).setOnCancelListener(d->latch.countDown()).show()); try{latch.await(60,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();} return ok.get(); }
                    public void showMessage(String m){}
                });
                session.connect(7000);
                String cmd="uname -a; echo '\\n--- ARCH ---'; uname -m; echo '\\n--- CPUINFO ---'; head -n 24 /proc/cpuinfo; echo '\\n--- OS RELEASE ---'; cat /etc/os-release 2>/dev/null | head -n 12";
                ChannelExec ch=(ChannelExec)session.openChannel("exec"); ch.setCommand(cmd); ch.setInputStream(null); ByteArrayOutputStream out=new ByteArrayOutputStream(); ch.setOutputStream(out); ch.connect(5000);
                long end=System.currentTimeMillis()+10000; while(!ch.isClosed()&&System.currentTimeMillis()<end) Thread.sleep(150); ch.disconnect(); result=out.toString("UTF-8"); if(result.trim().isEmpty()) result="Nema izlaza komandi ili uređaj ne dozvoljava njihovo izvršavanje.";
            }catch(Exception e){result="SSH inspekcija nije uspela: "+e.getMessage();}finally{if(session!=null)session.disconnect();}
            final String r=result; runOnUiThread(()->{output.append("\n\n===== SSH SYSTEM INSPECTION =====\n"+r+"\n");status.setText("SSH inspekcija završena");});
        }).start();
    }
    private void saveReport(){ Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"netscope-report.txt");startActivityForResult(i,11); }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{if(req==PICK_TXT){InputStream in=getContentResolver().openInputStream(data.getData());BufferedReader r=new BufferedReader(new InputStreamReader(in));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line).append('\n');targets.append((targets.length()>0?",":"")+b.toString().replace('\n',','));in.close();}else if(req==11){java.io.OutputStream o=getContentResolver().openOutputStream(data.getData());o.write(output.getText().toString().getBytes(StandardCharsets.UTF_8));o.close();toast("Izveštaj sačuvan.");}}catch(Exception e){toast("Greška: "+e.getMessage());}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){scanning=false;if(pool!=null)pool.shutdownNow();super.onDestroy();}
}
